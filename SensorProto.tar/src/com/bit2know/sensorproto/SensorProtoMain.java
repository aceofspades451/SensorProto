package com.bit2know.sensorproto;

import android.location.*;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.Menu;
import android.widget.TextView;

import com.jjoe64.graphview.*;

public class SensorProtoMain extends Activity {

	android.widget.TextView _latTextView;
	android.widget.TextView _lonTextView;
	android.widget.TextView _statTextView;
	android.location.LocationManager _locationManager;
	LocationListener Listener = new LocationListener()
	{

		@Override
		public void onLocationChanged(Location location) {
			Double lat = location.getLatitude();
			Double lon = location.getLongitude();
			_latTextView.setText(lat.toString());
			_lonTextView.setText(lon.toString());
			
			
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}
		
		
	};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proto_main);
        _latTextView = (TextView) findViewById(R.id.LatTextView);
        _lonTextView = (TextView) findViewById(R.id.LogTextView);
        _statTextView = (TextView) findViewById(R.id.statusTextView);
        _locationManager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);
        _locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, Listener);
        		
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_sensor_proto_main, menu);
        return true;
    }
    
    
    
    
}
