/** Automatically generated file. DO NOT MODIFY */
package com.bit2know.sensorproto;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}